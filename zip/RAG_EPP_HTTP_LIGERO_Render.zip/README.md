# RAG EPP HTTP liviano (TF-IDF)

Este paquete permite desbloquear Render Free **sin PyTorch, CUDA ni Transformers**. Utiliza la variante TF-IDF del notebook (palabras y bigramas; normalización y coseno). **No** es el Transformer evaluado con 75 % / 100 %. Los resultados deben evaluarse nuevamente si se usan en otra etapa.

## Subir a GitHub
Crea una rama o copia de respaldo, y reemplaza `main.py` y `requirements.txt` por estas versiones. Mantén `procedimientos.csv` y agrega `.python-version` si no existe.

## Render
- Runtime: Python, versión 3.11.11 (variable `PYTHON_VERSION`).
- Build Command: `pip install --no-cache-dir -r requirements.txt` (IMPORTANTE: quitar cualquier instalación de torch).
- Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Environment variable: `RAG_API_KEY` = secreto largo que solo tú controles.
- Health check: `/health`.
- Manual Deploy > Clear build cache & deploy.

## Pruebas
GET `/health` no requiere clave y devuelve estado y 7 documentos.
POST `/buscar`: header `Authorization: Bearer TU_CLAVE`; `Content-Type: application/json`.
JSON de ejemplo: `{ "pregunta":"El chaleco no se confirma, ¿qué hacer?", "zona_id":"zona_1", "inspeccion_id":"DEMO-001", "k":3 }`.

## n8n Cloud
Añade `HTTP Request` después del nodo YOLO: Method POST, URL `https://TU-SERVICIO.onrender.com/buscar`, header Authorization Bearer TU_CLAVE (idealmente usando credenciales n8n), Send Body JSON. **Antes de integrar**, comprueba que el código siguiente toma el JSON de YOLO del nodo correcto. El resultado contiene `contexto_para_llm`, `documentos_recuperados`, `modelo_busqueda`, `requiere_revision_humana`, etc.

## Seguridad
Los procedimientos son simulados, no son normas. No sancionar ni enviar recomendaciones sin revisión humana. No incluir la clave en GitHub. Evita enviar imágenes o datos personales a la API: solo envía consulta, zona e identificador técnico.
