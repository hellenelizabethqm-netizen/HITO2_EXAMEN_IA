"""API ligera RAG Hito 2. Usa TF-IDF baseline, NO Transformer.
No modifica datos del Hito 1 ni realiza sanciones.
"""
import csv
import math
import os
import re
import unicodedata
from collections import Counter
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field

MODELO = "TF-IDF (baseline, palabras y bigramas)"
with Path(__file__).with_name("procedimientos.csv").open(encoding="utf-8-sig", newline="") as f:
    DOCUMENTOS = list(csv.DictReader(f))
assert len(DOCUMENTOS) == 7

def palabras(texto):
    texto = unicodedata.normalize("NFKD", str(texto).lower())
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.findall(r"(?u)\b\w\w+\b", texto)

def terminos(texto):
    tokens = palabras(texto)
    return tokens + [a + " " + b for a, b in zip(tokens, tokens[1:])]

contenidos = [d["titulo"] + ". " + d["texto"] for d in DOCUMENTOS]
corpus = [Counter(terminos(t)) for t in contenidos]
df = Counter()
for c in corpus:
    df.update(c.keys())
N = len(corpus)
idf = {t: math.log((1 + N) / (1 + freq)) + 1 for t, freq in df.items()}

def vectorizar(conteos):
    pesos = {t: float(n) * idf[t] for t, n in conteos.items() if t in idf}
    norma = math.sqrt(sum(v*v for v in pesos.values()))
    return {t: v / norma for t, v in pesos.items()} if norma else {}

vectores = [vectorizar(c) for c in corpus]
app = FastAPI(title="RAG EPP Hito 2 - TF-IDF liviano", version="1.0")

class Consulta(BaseModel):
    pregunta: str = Field(min_length=3, max_length=2000)
    zona_id: str
    inspeccion_id: str = Field(default="DEMO-RAG-001", max_length=120)
    k: int = Field(default=3, ge=1, le=7)

@app.get("/health")
def health():
    return {"estado": "ok", "documentos": N, "modelo_busqueda": MODELO}

@app.post("/buscar")
def buscar(payload: Consulta, authorization: str | None = Header(default=None)):
    clave = os.environ.get("RAG_API_KEY", "").strip()
    if not clave:
        raise HTTPException(503, "Configura RAG_API_KEY en Render")
    if authorization != "Bearer " + clave:
        raise HTTPException(401, "Token inválido")
    if payload.zona_id not in {"zona_1", "zona_2", "ambas"}:
        raise HTTPException(422, "Zona no válida")
    idx = [i for i,d in enumerate(DOCUMENTOS) if payload.zona_id == "ambas" or d["zona_id"] in {payload.zona_id,"ambas"}]
    consulta = vectorizar(Counter(terminos(payload.pregunta)))
    puntuaciones = [(i, sum(vectores[i].get(t,0)*p for t,p in consulta.items())) for i in idx]
    puntuaciones.sort(key=lambda x: -x[1])
    seleccion = [(i,s) for i,s in puntuaciones if s > 0][:payload.k]
    fuentes=[]
    for i,s in seleccion:
        d=DOCUMENTOS[i]
        fuentes.append({"procedimiento_id":d["procedimiento_id"], "titulo":d["titulo"], "texto":d["texto"], "zona_id":d["zona_id"], "similitud":round(s,4), "fuente_datos":"SIMULADO", "validado_profesionalmente":False})
    return {
        "inspeccion_id":payload.inspeccion_id,"zona_id":payload.zona_id,"consulta":payload.pregunta,
        "componente":"RAG_procedimientos_hito2", "modelo_busqueda":MODELO,
        "documentos_recuperados":fuentes,
        "contexto_para_llm":"\n".join(f"[{f['procedimiento_id']}] {f['titulo']}: {f['texto']}" for f in fuentes),
        "indicacion_para_llm":"Usa exclusivamente los documentos recuperados y cita sus IDs. Si falta evidencia responde sin información suficiente. Procedimientos SIMULADOS no validados profesionalmente. Nunca confirmes incumplimientos sin revisión humana.",
        "requiere_revision_humana":True,
        "evidencia_suficiente_para_recuperacion":bool(seleccion)
    }
