# RAG EPP Hito 2 — API para Render

API demostrativa construida con los **7 procedimientos simulados exportados desde Colab**, utilizando el modelo `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`.

## Archivos

- `main.py`: FastAPI con `GET /health` y `POST /buscar`.
- `procedimientos.csv`: los 7 procedimientos originales del archivo `Resultados_RAG_Hito2.zip`.
- `requirements.txt`: dependencias Python.
- `.python-version`: versión Python sugerida.

## Despliegue

1. Crear un **repositorio nuevo** en GitHub y subir estos archivos (no incluir el ZIP del Hito 1).
2. En Render, crear **New > Web Service**, conectar el repositorio y seleccionar Python.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. En *Environment*, agregar `RAG_API_KEY` con una clave larga y privada. **No subir la clave a GitHub.**
6. Después del despliegue, comprobar `https://TU-SERVICIO.onrender.com/health`.
7. En n8n, usar un nodo HTTP Request con POST a `https://TU-SERVICIO.onrender.com/buscar`, encabezado `Authorization: Bearer TU_CLAVE`, y cuerpo JSON:

```json
{
  "inspeccion_id": "DEMO-RAG-001",
  "zona_id": "zona_1",
  "pregunta": "En la zona 1 el detector no confirma el chaleco: ¿qué corresponde hacer?",
  "k": 3
}
```

La respuesta conserva los campos `documentos_recuperados`, `contexto_para_llm`, `indicacion_para_llm` y `requiere_revision_humana` necesarios para la integración de n8n/Gemini.

## Límites importantes

- **Simulado / no validado:** los 7 documentos no son normas profesionales. No usar para sanciones o decisiones automáticas.
- **Diferencia con Colab:** el archivo CSV exportado no incluye la columna original `contenido`. Esta versión representa cada documento como `titulo + '. ' + texto`, por lo que el orden y las similitudes pueden diferir de los valores del notebook. Verificar esa construcción antes de afirmar reproducción exacta de la evaluación 6.4.
- **Memoria:** el modelo multilingüe pesa cientos de MB y requiere memoria adicional para PyTorch y sus dependencias. **El plan gratuito de Render puede quedarse sin memoria o fallar en el inicio.** Si sucede, usar un plan con más memoria o replantear el despliegue sin cambiar inadvertidamente el modelo evaluado.
- **Inactividad:** los servicios gratuitos de Render se suspenden tras un periodo sin tráfico y tardan en despertar.
- **Seguridad:** proteger la API con `RAG_API_KEY`, no enviar imágenes ni datos personales cuando basta una consulta resumida, y mantener revisión humana antes de emitir recomendaciones.
- **n8n:** no modificar el workflow de YOLO en producción hasta verificar el servicio y un flujo de prueba. Mantener separados los archivos del Hito 1.
