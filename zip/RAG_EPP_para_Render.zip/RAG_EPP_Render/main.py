"""API RAG demostrativa para el Hito 2 EPP.

IMPORTANTE: Los procedimientos son simulados y NO están validados profesionalmente.
Esta API no determina infracciones ni aprueba recomendaciones.
"""
import csv
import os
from contextlib import asynccontextmanager
from pathlib import Path

import numpy as np
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer

MODELO_NOMBRE = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
DATA_FILE = Path(__file__).with_name('procedimientos.csv')

with DATA_FILE.open('r', encoding='utf-8-sig', newline='') as f:
    DOCUMENTOS = list(csv.DictReader(f))

if len(DOCUMENTOS) != 7:
    raise RuntimeError('Se esperaban exactamente 7 procedimientos simulados.')

# Reconstrucción de contenido: el CSV exportado incluye titulo y texto,
# pero no la columna 'contenido' exacta utilizada originalmente en Colab.
# Revisar contra el notebook si se requiere reproducir puntajes idénticos.
CONTENIDOS = [f"{d['titulo']}. {d['texto']}" for d in DOCUMENTOS]
modelo = None
embeddings = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global modelo, embeddings
    modelo = SentenceTransformer(MODELO_NOMBRE, device='cpu')
    embeddings = modelo.encode(CONTENIDOS, normalize_embeddings=True, show_progress_bar=False)
    yield

app = FastAPI(title='RAG EPP Hito 2 - Demostración', version='1.0.0', lifespan=lifespan)

class Consulta(BaseModel):
    pregunta: str = Field(min_length=3, max_length=2000)
    zona_id: str
    inspeccion_id: str = Field(default='DEMO-RAG-001', max_length=120)
    k: int = Field(default=3, ge=1, le=7)

@app.get('/health')
def health():
    return {'estado': 'ok', 'documentos': len(DOCUMENTOS), 'modelo_cargado': modelo is not None}

@app.post('/buscar')
def buscar(payload: Consulta, authorization: str | None = Header(default=None)):
    clave = os.environ.get('RAG_API_KEY', '').strip()
    if not clave:
        raise HTTPException(status_code=503, detail='Configurar RAG_API_KEY en Render antes de usar /buscar.')
    if authorization != f'Bearer {clave}':
        raise HTTPException(status_code=401, detail='Token de acceso no válido.')
    if payload.zona_id not in ('zona_1', 'zona_2', 'ambas'):
        raise HTTPException(status_code=422, detail='zona_id debe ser zona_1, zona_2 o ambas.')
    if modelo is None or embeddings is None:
        raise HTTPException(status_code=503, detail='El modelo todavía no está disponible.')

    indices = [i for i, doc in enumerate(DOCUMENTOS)
               if payload.zona_id == 'ambas' or doc['zona_id'] in (payload.zona_id, 'ambas')]
    q = modelo.encode([payload.pregunta], normalize_embeddings=True, show_progress_bar=False)[0]
    puntuaciones = embeddings[indices] @ q
    orden = np.argsort(-puntuaciones)[:payload.k]

    fuentes = []
    for pos in orden:
        d = DOCUMENTOS[indices[int(pos)]]
        fuentes.append({
            'procedimiento_id': d['procedimiento_id'],
            'titulo': d['titulo'],
            'texto': d['texto'],
            'zona_id': d['zona_id'],
            'similitud': round(float(puntuaciones[pos]), 4),
            'fuente_datos': 'SIMULADO',
            'validado_profesionalmente': False,
        })
    referencias = '\n'.join(
        f"[{f['procedimiento_id']}] {f['titulo']}: {f['texto']}" for f in fuentes
    )
    return {
        'inspeccion_id': payload.inspeccion_id,
        'zona_id': payload.zona_id,
        'consulta': payload.pregunta,
        'componente': 'RAG_procedimientos_hito2',
        'modelo_busqueda': MODELO_NOMBRE,
        'documentos_recuperados': fuentes,
        'contexto_para_llm': referencias,
        'indicacion_para_llm': (
            'Usa exclusivamente los documentos recuperados y cita sus IDs. '
            'Si falta evidencia, responde sin informacion suficiente. '
            'Los procedimientos son SIMULADOS y NO están validados profesionalmente. '
            'No afirmes incumplimiento de EPP sin revisión humana.'
        ),
        'requiere_revision_humana': True,
    }
